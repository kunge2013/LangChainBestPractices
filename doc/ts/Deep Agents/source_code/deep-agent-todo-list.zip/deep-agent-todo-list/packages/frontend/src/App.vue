<script setup lang="ts">
import DeepAgentTodoListPreview from "./patterns/deep-agent-todo-list/Preview.vue";
</script>

<template>
  <DeepAgentTodoListPreview />
</template>
